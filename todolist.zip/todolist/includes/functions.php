<?php
/**
 * ============================================================
 *  functions.php
 *  ----------------------------------------------------------
 *  Berisi seluruh logika aplikasi To-Do List.
 *  Menggunakan pendekatan PEMROGRAMAN TERSTRUKTUR:
 *  - Setiap fungsi memiliki satu tanggung jawab.
 *  - Struktur data : array of objects.
 *  - Kode ditulis agar mudah dibaca dan dirawat.
 * ============================================================
 */


/* ============================================================
 * 1. DATA AWAL
 * ============================================================ */

/**
 * Membuat data awal tugas dalam bentuk array of objects.
 *
 * @return array Daftar tugas awal.
 */
function tugasAwal(): array
{
    return [
        ['id' => 1, 'title' => 'Belajar PHP', 'status' => 'belum'],
        ['id' => 2, 'title' => 'Kerjakan tugas UX', 'status' => 'selesai'],
    ];
}


/* ============================================================
 * 2. AKSES & PENYIMPANAN DATA (SESSION)
 * ============================================================ */

/**
 * Mengambil daftar tugas dari session.
 * Bila belum tersedia, diinisialisasi dengan data awal.
 *
 * @return array Daftar tugas.
 */
function ambilTugas(): array
{
    if (!isset($_SESSION['tasks'])) {
        $_SESSION['tasks'] = tugasAwal();
    }
    return $_SESSION['tasks'];
}

/**
 * Menyimpan daftar tugas ke dalam session.
 *
 * @param array $tasks Daftar tugas.
 * @return void
 */
function simpanTugas(array $tasks): void
{
    $_SESSION['tasks'] = $tasks;
}


/* ============================================================
 * 3. MANIPULASI DATA (CRUD)
 * ============================================================ */

/**
 * Menambahkan tugas baru ke akhir array.
 *
 * @param array  $tasks Referensi array tugas.
 * @param string $title Judul tugas baru.
 * @return void
 */
function tambahTugas(array &$tasks, string $title): void
{
    $title = trim($title);
    if ($title === '') {
        return;
    }

    // Tentukan id berikutnya secara otomatis.
    $id = count($tasks) > 0 ? (int) max(array_column($tasks, 'id')) + 1 : 1;

    $tasks[] = [
        'id'     => $id,
        'title'  => $title,
        'status' => 'belum',
    ];

    simpanTugas($tasks);
}

/**
 * Mengubah status tugas (belum <-> selesai) berdasarkan id.
 *
 * @param array $tasks Referensi array tugas.
 * @param int   $id    Id tugas yang diubah.
 * @return bool true bila id ditemukan, false bila tidak.
 */
function ubahStatus(array &$tasks, int $id): bool
{
    foreach ($tasks as &$tugas) {
        if ((int) $tugas['id'] === $id) {
            $tugas['status'] = ($tugas['status'] === 'selesai') ? 'belum' : 'selesai';
            simpanTugas($tasks);
            unset($tugas);
            return true;
        }
    }
    return false;
}

/**
 * Menghapus tugas berdasarkan id menggunakan array_filter.
 *
 * @param array $tasks Referensi array tugas.
 * @param int   $id    Id tugas yang dihapus.
 * @return bool true bila ada data yang dihapus, false bila tidak.
 */
function hapusTugas(array &$tasks, int $id): bool
{
    $jumlahAwal = count($tasks);

    $tasks = array_values(
        array_filter($tasks, static fn ($tugas) => (int) $tugas['id'] !== $id)
    );

    if (count($tasks) !== $jumlahAwal) {
        simpanTugas($tasks);
        return true;
    }
    return false;
}
function hapusSemuaTugas(array &$tasks): bool
{
    $tasks = [];
    simpanTugas($tasks);
    return true;
}

/**
 * Mengubah status seluruh tugas menjadi 'selesai' atau 'belum'.
 *
 * @param array  $tasks Referensi array tugas.
 * @param string $status Target status: 'selesai' atau 'belum'.
 * @return void
 */
function ubahSemuaStatus(array &$tasks, string $status): void
{
    foreach ($tasks as &$tugas) {
        $tugas['status'] = $status;
    }
    unset($tugas);
    simpanTugas($tasks);
}
/* ============================================================
 * 4. PEMROSESAN AKSI DARI USER
 * ============================================================ */

/**
 * Memproses aksi tambah / ubah status / hapus tugas.
 * Membaca input dari $_POST dan $_GET lalu mengembalikan pesan.
 *
 * @param array $tasks Referensi array tugas.
 * @return string HTML notifikasi (dapat berupa string kosong).
 */
function prosesAksi(array &$tasks): string
{
    // Aksi tambah tugas (data dikirim via form / POST).
    if (isset($_POST['tambah'], $_POST['judul'])) {
        tambahTugas($tasks, $_POST['judul']);
        return notifikasi('Tugas baru berhasil ditambahkan.', 'success');
    }

    // Aksi ubah status via checkbox (POST).
    if (isset($_POST['aksi'], $_POST['id']) && $_POST['aksi'] === 'ubah') {
        ubahStatus($tasks, (int) $_POST['id']);
        return notifikasi('Status tugas berhasil diperbarui.', 'info');
    }

    // Aksi hapus tugas (GET).
    if (isset($_GET['aksi'], $_GET['id']) && $_GET['aksi'] === 'hapus') {
        hapusTugas($tasks, (int) $_GET['id']);
        return notifikasi('Tugas berhasil dihapus.', 'warning');
    }

    // Aksi centang semua (POST, lewat tombol toggle).
    if (isset($_POST['aksi']) && $_POST['aksi'] === 'check_all') {
        ubahSemuaStatus($tasks, 'selesai');
        return notifikasi('Semua tugas ditandai selesai.', 'success');
    }

    // Aksi hapus centang semua (POST, lewat tombol toggle).
    if (isset($_POST['aksi']) && $_POST['aksi'] === 'uncheck_all') {
        ubahSemuaStatus($tasks, 'belum');
        return notifikasi('Status semua tugas dikembalikan ke belum.', 'info');
    }

    // Aksi hapus semua tugas (POST).
    if (isset($_POST['aksi']) && $_POST['aksi'] === 'delete_all') {
        hapusSemuaTugas($tasks);
        return notifikasi('Semua tugas berhasil dihapus.', 'danger');
    }

    return '';
}

/**
 * Membuat template notifikasi alert Bootstrap 5.
 *
 * @param string $pesan Isi teks pesan.
 * @param string $tipe  Tipe alert: success | info | warning | danger.
 * @return string HTML alert.
 */
function notifikasi(string $pesan, string $tipe): string
{
    // Kurung di sekitar kondisi ternary memastikan prioritas evaluasi benar.
    // Tanpa kurung, operator '.' lebih kuat daripada '?:' sehingga fallback
    // 'secondary' tidak pernah digunakan saat $tipe bernilai tidak valid.
    $kelas = 'alert-' . (in_array($tipe, ['success', 'info', 'warning', 'danger'], true)
        ? $tipe
        : 'secondary');

    return '<div class="alert ' . $kelas . ' alert-dismissible fade show" role="alert">'
        . htmlspecialchars($pesan)
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>'
        . '</div>';
}


/* ============================================================
 * 5. RENDER TAMPILAN
 * ============================================================ */

/**
 * Menampilkan daftar tugas menggunakan perulangan foreach.
 * Setiap baris berisi checkbox (ubah status) dan tombol hapus.
 *
 * @param array $tasks Daftar tugas.
 * @return void
 */
function tampilkanDaftar(array $tasks): void
{
    if (empty($tasks)) {
        echo '<div class="alert alert-info text-center py-4">'
            . 'Belum ada tugas. Silakan <strong>tambah tugas</strong> terlebih dahulu.'
            . '</div>';
        return;
    }

    echo '<ul class="list-group list-group-flush">';

    foreach ($tasks as $tugas) {
        $id      = (int) $tugas['id'];
        $judul   = htmlspecialchars($tugas['title']);
        $selesai = ($tugas['status'] === 'selesai');
        $gores   = $selesai ? 'text-decoration-line-through text-muted' : '';

        echo '<li class="list-group-item bg-transparent d-flex align-items-center justify-content-between">';

        // Form untuk checkbox yang otomatis ter-submit ketika dicentang.
        echo '<form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF']) . '"
                 class="d-flex align-items-center w-100">'
            . '<input type="hidden" name="aksi" value="ubah">'
            . '<input type="hidden" name="id" value="' . $id . '">'
            . '<div class="form-check">'
            . '<input class="form-check-input" type="checkbox" name="status" value="selesai" '
            . 'id="tugas-' . $id . '"' . ($selesai ? ' checked' : '') . ' onchange="this.form.submit()">'
            . '<label class="form-check-label ' . $gores . '" for="tugas-' . $id . '">' . $judul . '</label>'
            . '</div>'
            . '</form>';

        // Tombol hapus tugas.
        echo '<a href="?aksi=hapus&id=' . $id . '" class="btn btn-outline-danger btn-sm ms-3 flex-shrink-0"
                 onclick="return confirm(\'Yakin ingin menghapus tugas ini?\')">'
            . '<i class="bi bi-trash"></i> Hapus'
            . '</a>';

        echo '</li>';
    }

    echo '</ul>';
}

/**
 * Menghitung jumlah tugas berdasarkan status.
 *
 * @param array  $tasks  Daftar tugas.
 * @param string $status Kategori: 'semua', 'selesai', atau 'belum'.
 * @return int Jumlah tugas.
 */
function hitungTugas(array $tasks, string $status): int
{
    if ($status === 'semua') {
        return count($tasks);
    }
    return count(array_filter($tasks, static fn ($tugas) => $tugas['status'] === $status));
}

/**
 * Menentukan apakah seluruh tugas sudah berstatus selesai.
 * Digunakan untuk memilih arah toggle tombol "centang semua".
 *
 * @param array $tasks Daftar tugas.
 * @return bool true bila semua tugas selesai (atau daftar kosong).
 */
function semuaSelesai(array $tasks): bool
{
    if (empty($tasks)) {
        return true;
    }
    foreach ($tasks as $tugas) {
        if ($tugas['status'] !== 'selesai') {
            return false;
        }
    }
    return true;
}