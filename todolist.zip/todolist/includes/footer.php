<?php
/**
 * footer.php - Bagian akhir layout (penutup main, footer, skrip JS).
 */
?>
</main>

<!-- ============================
     FOOTER APLIKASI
     ============================ -->
<footer class="text-center text-muted py-4">
    <small>Aplikasi To-Do List &mdash; Pemrograman Terstruktur &amp; Array of Objects</small>
</footer>

<!-- Bootstrap 5 JS (CDN) - untuk komponen interaktif seperti alert -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>