<?php
/**
 * header.php - Bagian awal layout (doctype, head, header navigasi).
 * Digunakan bersama oleh seluruh halaman aplikasi.
 */
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>

    <!-- Bootstrap 5 CSS (CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons (CDN) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Gaya kustom aplikasi -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- ============================
     HEADER APLIKASI
     ============================ -->
<header class="app-header text-center py-4 mb-4">
    <div class="container">
        <h1 class="fw-bold mb-1"><i class="bi bi-list-check"></i> To-Do List</h1>
        <p class="mb-0 opacity-75">Kelola tugas harianmu dengan mudah</p>
    </div>
</header>

<main class="container pb-5" style="max-width: 720px;">