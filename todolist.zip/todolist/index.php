<?php
/**
 * ============================================================
 *  index.php - Halaman utama aplikasi To-Do List.
 *  ----------------------------------------------------------
 *  Alur program:
 *    1. Inisialisasi session & memuat logika dari functions.php.
 *    2. Mengambil data tugas dari session.
 *    3. Memproses aksi (tambah / ubah status / hapus).
 *    4. Menghitung statistik.
 *    5. Menampilkan tampilan (header, konten, footer).
 * ============================================================
 */

session_start();

require_once __DIR__ . '/includes/functions.php';

// Ambil daftar tugas dari session.
$tasks = ambilTugas();

// Proses aksi dari user dan ambil pesan notifikasinya.
$notifikasi = prosesAksi($tasks);

// Siapkan data statistik untuk kartu ringkasan.
$statistik = [
    'semua'   => hitungTugas($tasks, 'semua'),
    'selesai' => hitungTugas($tasks, 'selesai'),
    'belum'   => hitungTugas($tasks, 'belum'),
];

require_once __DIR__ . '/includes/header.php';
?>

<!-- Notifikasi aksi (jika ada) -->
<?php echo $notifikasi; ?>

<!-- ============================
     RINGKASAN STATISTIK
     ============================ -->
<div class="row text-center g-2 mb-4">
    <div class="col-4">
        <div class="card shadow-sm p-3">
            <h4 class="fw-bold text-primary mb-0"><?php echo $statistik['semua']; ?></h4>
            <small class="text-muted">Total</small>
        </div>
    </div>
    <div class="col-4">
        <div class="card shadow-sm p-3">
            <h4 class="fw-bold text-success mb-0"><?php echo $statistik['selesai']; ?></h4>
            <small class="text-muted">Selesai</small>
        </div>
    </div>
    <div class="col-4">
        <div class="card shadow-sm p-3">
            <h4 class="fw-bold text-warning mb-0"><?php echo $statistik['belum']; ?></h4>
            <small class="text-muted">Belum</small>
        </div>
    </div>
</div>

<!-- ============================
     FORM TAMBAH TUGAS
     ============================ -->
<div class="card p-4 mb-4">
    <h5 class="mb-3"><i class="bi bi-plus-circle"></i> Tambah Tugas Baru</h5>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <div class="input-group">
            <input type="text" name="judul" class="form-control" placeholder="Ketik nama tugas..."
                required autofocus>
            <button type="submit" name="tambah" class="btn btn-primary px-4">
                <i class="bi bi-plus-lg"></i> Tambah
            </button>
        </div>
    </form>
</div>

<!-- ============================
     FORM EDIT TUGAS (muncul saat ?edit=ID)
     ============================ -->
<?php
// Deteksi mode edit: tampilkan form bila ada parameter ?edit=ID dan tugas ditemukan.
$tugasEdit = isset($_GET['edit']) ? cariTugas($tasks, (int) $_GET['edit']) : null;

if ($tugasEdit !== null):
?>
<div class="card border-warning p-4 mb-4">
    <h5 class="mb-3 text-warning"><i class="bi bi-pencil-square"></i> Edit Tugas</h5>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <input type="hidden" name="aksi" value="edit">
        <input type="hidden" name="id" value="<?php echo (int) $tugasEdit['id']; ?>">
        <div class="input-group">
            <input type="text" name="judul" class="form-control"
                value="<?php echo htmlspecialchars($tugasEdit['title']); ?>" required autofocus>
            <button type="submit" class="btn btn-warning px-4">
                <i class="bi bi-save"></i> Simpan
            </button>
            <a href="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" class="btn btn-outline-secondary">
                Batal
            </a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- ============================
     DAFTAR TUGAS
     ============================ -->
<div class="card p-4">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
        <h5 class="mb-0"><i class="bi bi-list-task"></i> Daftar Tugas</h5>

        <?php
        // Tentukan arah tombol toggle: jika semua sudah selesai -> hapus centang,
        // selain itu -> centang semua.
        $toggleAksi = semuaSelesai($tasks) ? 'uncheck_all' : 'check_all';
        $toggleLabel = semuaSelesai($tasks) ? 'Batal centang semua' : 'Centang semua';
        ?><div class="btn-group btn-group-sm">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <input type="hidden" name="aksi" value="<?php echo $toggleAksi; ?>">
                <button type="submit" class="btn btn-outline-success">
                    <i class="bi bi-check-all"></i> <?php echo $toggleLabel; ?>
                </button>
            </form>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                  onsubmit="return confirm('Yakin ingin menghapus SEMUA tugas?')">
                <input type="hidden" name="aksi" value="delete_all">
                <button type="submit" class="btn btn-outline-danger">
                    <i class="bi bi-trash"></i> Hapus semua
                </button>
            </form>
        </div>
    </div>

    <?php
    // Tampilkan daftar tugas dengan checkbox dan tombol hapus.
    tampilkanDaftar($tasks);
    ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>